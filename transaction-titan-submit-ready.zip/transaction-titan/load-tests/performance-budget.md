# Performance Budget

Target p99: **100 ms**

  Stage                          Budget
  ------------------------ ------------
  Gateway + auth                  10 ms
  Validation/idempotency           5 ms
  Fraud/risk                      20 ms
  Account/payment                 35 ms
  DB commit/ledger                20 ms
  Serialization/network           10 ms
  **Total**                  **100 ms**

These are allocation targets and must be validated with measurements.
