# Pseudocode: 70% payments, 15% account reads, 10% history, 5% settlement/status
start_mixed_load(total_tps=12000, duration_minutes=60)
assert_p99_below(100)
assert_no_unbounded_consumer_lag()
assert_financial_reconciliation()
