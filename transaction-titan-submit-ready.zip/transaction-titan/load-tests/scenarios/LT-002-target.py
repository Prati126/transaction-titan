# Pseudocode: 12,000 TPS for 60 minutes
def payment():
    post(
        "/v1/payments",
        json={
            "sourceAccountId": random_account(),
            "destinationAccountId": random_account(),
            "amountMinor": random_amount(),
            "currency": "INR"
        },
        headers={"Idempotency-Key": unique_key()}
    )

# Scale load generators until aggregate throughput = 12,000 TPS.
# Pass: p99 <100ms and no unbounded Kafka/DB queue growth.
