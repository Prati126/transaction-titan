# Pseudocode: DB failover at T+10m
start_load(12000)
warm_up(10)
kill_database_primary()
observe(latency=True, errors=True, replication_lag=True)
run_for(20)
assert_no_duplicate_ledger_entries()
assert_financial_reconciliation()
