# ADR-005: Cache Invalidation Strategy

**Status:** Accepted

Redis is a low-latency acceleration layer, not the financial source of
truth.

Mutable account data uses versioned values, TTLs and event-driven
invalidation. A stale cache must never authorize a financial debit. The
database is authoritative.
