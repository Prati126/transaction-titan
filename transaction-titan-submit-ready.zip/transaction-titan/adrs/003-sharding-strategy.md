# ADR-003: Sharding Strategy

**Status:** Accepted

Use `account_id` as the logical shard key with explicit routing. The 24K
TPS planning model uses 12 shard groups at an assumed 2K TPS per group.

The trade-off is operational complexity around hot accounts, routing and
rebalancing.
