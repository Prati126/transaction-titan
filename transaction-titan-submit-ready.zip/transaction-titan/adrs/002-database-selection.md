# ADR-002: Database Selection

**Status:** Accepted

## Decision

Use PostgreSQL-compatible sharded relational storage.

## Rationale

Financial data requires strong relational constraints, transactional
updates, mature indexing and clear schema control. Account affinity
reduces cross-shard operations.

## Trade-off

Application-aware routing and rebalancing become explicit operational
responsibilities.
