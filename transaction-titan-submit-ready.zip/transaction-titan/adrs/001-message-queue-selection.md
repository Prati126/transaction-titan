# ADR-001: Message Queue Selection

**Status:** Accepted

## Decision

Use Kafka as the primary event backbone.

## Context

The platform needs high throughput, partitioned processing,
replayability and independent consumer scaling for notifications,
settlement, fraud events and audit streams.

## Consequences

Kafka adds partition planning and operational complexity, but provides
the event-stream properties needed by this architecture. Consumer
idempotency is still required.
