# ADR-004: Synchronous vs Asynchronous Communication

**Status:** Accepted

Use synchronous communication only for transaction-critical
authorization decisions. Use Kafka for notifications, settlement
preparation, analytics and other side effects.

This keeps the p99 critical path short and limits cascading failures.
