def handle_idempotent_command(key, request_hash, handler):
    record = store.get(key)

    if record:
        if record.request_hash != request_hash:
            raise ConflictError("IDEMPOTENCY_KEY_REUSED")
        if record.status == "COMPLETED":
            return record.response
        if record.status == "IN_PROGRESS":
            raise RetryableError("REQUEST_IN_PROGRESS")

    created = store.create_if_absent(key, request_hash, "IN_PROGRESS")
    if not created:
        return handle_idempotent_command(key, request_hash, handler)

    try:
        response = handler()
        store.complete(key, response)
        return response
    except Exception:
        store.expire_or_mark_failed(key)
        raise
