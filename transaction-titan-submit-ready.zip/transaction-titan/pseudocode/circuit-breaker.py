class CircuitBreaker:
    CLOSED, OPEN, HALF_OPEN = "CLOSED", "OPEN", "HALF_OPEN"

    def __init__(self, threshold=0.50, cooldown=30):
        self.state = self.CLOSED
        self.threshold = threshold
        self.cooldown = cooldown
        self.opened_at = None

    def allow(self):
        if self.state == self.CLOSED:
            return True
        if self.state == self.OPEN:
            if now() - self.opened_at >= self.cooldown:
                self.state = self.HALF_OPEN
                return True
            return False
        return True

    def record_success(self):
        self.state = self.CLOSED

    def record_failure(self):
        update_rolling_window()
        if failure_rate() >= self.threshold:
            self.state = self.OPEN
            self.opened_at = now()
