def execute_transfer(command):
    saga = load_or_create_saga(command.idempotency_key)
    if saga.completed:
        return saga.result

    try:
        debit_source(command)
        saga.record("DEBIT_COMPLETED")

        credit_destination(command)
        saga.record("CREDIT_COMPLETED")

        publish_event("transfer.completed", saga.id)
        saga.complete()
        return saga.result

    except RetryableError:
        schedule_retry(saga)
        raise

    except Exception as exc:
        if saga.has("DEBIT_COMPLETED") and not saga.has("CREDIT_COMPLETED"):
            create_compensating_action(command, saga)
        saga.fail(str(exc))
        raise
