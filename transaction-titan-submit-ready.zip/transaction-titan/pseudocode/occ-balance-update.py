def debit(account_id, amount_minor, transaction_id, idempotency_key):
    existing = find_by_idempotency_key(idempotency_key)
    if existing:
        return existing.result

    for attempt in range(MAX_RETRIES):
        account = read_account(account_id)

        if account.status != "ACTIVE":
            raise BusinessError("ACCOUNT_NOT_ACTIVE")
        if account.available_balance < amount_minor:
            raise BusinessError("INSUFFICIENT_FUNDS")

        updated = db.execute("""
            UPDATE accounts
            SET available_balance = :new_balance,
                version = version + 1,
                updated_at = now()
            WHERE account_id = :account_id
              AND version = :expected_version
              AND status = 'ACTIVE'
        """, account_id=account_id,
             new_balance=account.available_balance - amount_minor,
             expected_version=account.version)

        if updated.rowcount == 1:
            insert_transaction_and_ledger_atomically(
                transaction_id, account_id, amount_minor, idempotency_key)
            return "COMMITTED"

        backoff_with_jitter(attempt)

    raise RetryableError("OCC_CONFLICT")
