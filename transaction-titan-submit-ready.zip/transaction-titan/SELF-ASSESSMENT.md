# Self Assessment

-   [x] Day 1 scenario analysis
-   [x] Day 2 technology evaluation + ADRs
-   [x] Day 3 architecture
-   [x] Day 4 data flows
-   [x] Day 5 database schema
-   [x] Day 6 sharding
-   [x] Day 7 Kafka topology
-   [x] Day 8 concurrency
-   [x] Day 9 resilience
-   [x] Day 10 OpenAPI
-   [x] Day 11 load testing
-   [x] Day 12 capacity/cost
-   [x] Day 13 FMEA
-   [x] Day 14 ARB material

## Before submission

1.  Render all PlantUML/Draw.io diagrams.
2.  Validate OpenAPI.
3.  Check SQL against PostgreSQL.
4.  Re-check cost assumptions.
5.  Rehearse every quantitative claim.
