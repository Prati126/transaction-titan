CREATE TABLE transactions (
 transaction_id UUID NOT NULL, account_id UUID NOT NULL, counterparty_account_id UUID,
 idempotency_key VARCHAR(128) NOT NULL UNIQUE, amount_minor BIGINT NOT NULL CHECK(amount_minor > 0),
 currency CHAR(3) NOT NULL, transaction_type VARCHAR(30) NOT NULL,
 status VARCHAR(20) NOT NULL CHECK(status IN ('PENDING','COMPLETED','FAILED','HELD')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ,
 PRIMARY KEY(transaction_id, created_at)
) PARTITION BY RANGE(created_at);
CREATE INDEX idx_tx_account_time ON transactions(account_id, created_at DESC);
