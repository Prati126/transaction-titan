CREATE TABLE accounts (
 account_id UUID PRIMARY KEY, user_id UUID NOT NULL, currency CHAR(3) NOT NULL,
 available_balance BIGINT NOT NULL DEFAULT 0 CHECK (available_balance >= 0),
 version BIGINT NOT NULL DEFAULT 0 CHECK (version >= 0),
 status VARCHAR(20) NOT NULL CHECK (status IN ('ACTIVE','FROZEN','CLOSED')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_accounts_user ON accounts(user_id);
