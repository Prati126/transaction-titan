CREATE TABLE ledger_entries (
 entry_id UUID NOT NULL, transaction_id UUID NOT NULL, account_id UUID NOT NULL,
 direction CHAR(1) NOT NULL CHECK(direction IN ('D','C')),
 amount_minor BIGINT NOT NULL CHECK(amount_minor > 0), currency CHAR(3) NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(entry_id, created_at)
) PARTITION BY RANGE(created_at);
CREATE INDEX idx_ledger_account_time ON ledger_entries(account_id, created_at DESC);
