CREATE TABLE fraud_rules (
 rule_id UUID PRIMARY KEY, rule_name VARCHAR(120) NOT NULL UNIQUE, rule_version INT NOT NULL,
 rule_definition JSONB NOT NULL, enabled BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
