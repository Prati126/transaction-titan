CREATE TABLE merchant_settlements (
 settlement_id UUID PRIMARY KEY, merchant_id UUID NOT NULL, settlement_date DATE NOT NULL,
 amount_minor BIGINT NOT NULL CHECK(amount_minor >= 0), currency CHAR(3) NOT NULL,
 status VARCHAR(20) NOT NULL CHECK(status IN ('PENDING','PROCESSING','COMPLETED','FAILED')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ,
 UNIQUE(merchant_id, settlement_date, currency)
);
CREATE INDEX idx_settlement_merchant_date ON merchant_settlements(merchant_id, settlement_date);
