CREATE TABLE transaction_events (
 event_id UUID PRIMARY KEY, aggregate_id UUID NOT NULL, event_type VARCHAR(80) NOT NULL,
 payload JSONB NOT NULL, status VARCHAR(20) NOT NULL CHECK(status IN ('NEW','PUBLISHED','FAILED')),
 attempt_count INT NOT NULL DEFAULT 0 CHECK(attempt_count >= 0),
 next_attempt_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), published_at TIMESTAMPTZ
);
CREATE INDEX idx_events_publish ON transaction_events(status, next_attempt_at);
