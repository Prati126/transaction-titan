CREATE TABLE notification_log (
 notification_id UUID PRIMARY KEY, transaction_id UUID NOT NULL,
 channel VARCHAR(20) NOT NULL CHECK(channel IN ('SMS','EMAIL','PUSH')),
 status VARCHAR(20) NOT NULL CHECK(status IN ('PENDING','SENT','FAILED')),
 attempt_count INT NOT NULL DEFAULT 0, last_error TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), sent_at TIMESTAMPTZ,
 UNIQUE(transaction_id, channel)
);
