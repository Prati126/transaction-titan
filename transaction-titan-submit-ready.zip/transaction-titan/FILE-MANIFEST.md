# File Manifest

GitHub-ready Transaction Titan submission package.

Key directories: docs/, adrs/, diagrams/, schemas/, pseudocode/, api/, load-tests/.
