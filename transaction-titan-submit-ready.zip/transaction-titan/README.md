# Transaction Titan: The Scale Architect

**PayScale Financial Technologies --- transaction processing redesign**

**Targets:** 12,000 TPS sustained, 18,000 TPS burst, 24,000 TPS planning
capacity\
**SLA:** p99 \<100 ms, 99.99% availability\
**Residency:** India\
**Monthly infrastructure ceiling:** \$45,000

This repository is a complete architecture-design submission package
based on the supplied Transaction Titan assignment brief.

## Architecture decisions

1.  Kafka is the event backbone.
2.  PostgreSQL-compatible sharded relational storage is the financial
    system of record.
3.  Redis Cluster is the low-latency cache/idempotency acceleration
    layer.
4.  Account-based sharding minimizes cross-shard financial operations.
5.  OCC protects account balance updates from double-spend/write
    conflicts.
6.  Outbox-style durable events prevent database/message dual-write
    loss.
7.  Saga orchestration handles cross-shard workflows and compensation.
8.  Circuit breakers, bulkheads, retries and idempotency provide
    resilience.
9.  Transaction-critical work is synchronous; side effects are
    asynchronous.
10. Capacity is planned for 24,000 TPS, while 12,000 TPS is the business
    target.

> Review and customize assumptions and calculations before submission so
> you can explain every decision in the ARB.
