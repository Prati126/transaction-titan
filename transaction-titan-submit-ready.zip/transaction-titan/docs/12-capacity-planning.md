# Day 12 --- Capacity Planning & Cost

The supplied assignment's reference capacity model is:

  Component                                 Capacity     Monthly estimate
  -------------------------- ----------------------- --------------------
  API Gateway                            4 instances              \$1,200
  Transaction Orchestrator                         8              \$3,200
  Payment Service                                 12              \$6,000
  Account Service                                  6              \$1,800
  Fraud Detection                                  4              \$3,600
  Notification                                     3                \$450
  Kafka                                    3 brokers              \$3,600
  PostgreSQL                   4 shards × 3 replicas             \$14,400
  Redis                                      6 nodes              \$4,800
  Monitoring                                 3 nodes              \$1,800
  **Total**                                            **\$40,850/month**

The model is \$4,150 below the \$45,000 ceiling. The supplied figures
should be revalidated against current India-region cloud pricing before
a real procurement decision.
