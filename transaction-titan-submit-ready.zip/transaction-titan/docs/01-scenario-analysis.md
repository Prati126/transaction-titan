# Day 1 --- Scenario Analysis

## Executive summary

The current platform is approximately 1,200 TPS. The Diwali requirement
is 12,000 TPS sustained, 18,000 TPS burst and 24,000 TPS planning
capacity. The redesign must preserve financial correctness while
achieving p99 latency below 100 ms and 99.99% availability. Data must
remain in India and monthly infrastructure spend must stay below
\$45,000.

## Top five bottlenecks

  -----------------------------------------------------------------------
  Bottleneck              Risk at scale           Response
  ----------------------- ----------------------- -----------------------
  Database write          Balance/ledger writes   Sharding, partitioning,
  contention              serialize               OCC, pooling

  Synchronous             Latency compounds       Short critical path +
  dependencies                                    Kafka

  Hot accounts/partitions Uneven load             Hot-key detection and
                                                  routing controls

  Duplicate retries       Duplicate money         Idempotency + unique
                          movement                constraints

  Dependency failure      Cascading outage        Circuit breakers +
                                                  bulkheads
  -----------------------------------------------------------------------

## Success criteria

-   12,000 TPS sustained.
-   18,000 TPS burst.
-   24,000 TPS planning capacity.
-   p99 \<100 ms.
-   99.99% availability.
-   No double-spend.
-   India data residency.
-   Monthly infrastructure \<=\$45,000.
