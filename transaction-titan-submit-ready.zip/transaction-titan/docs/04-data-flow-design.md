# Day 4 --- Data Flow Design

## P2P happy path

1.  Client submits payment with an idempotency key.
2.  Gateway authenticates and rate-limits.
3.  Orchestrator checks idempotency.
4.  Fraud/risk checks required by policy.
5.  Account/payment service performs conditional balance update.
6.  Transaction and ledger records commit.
7.  Durable outbox event is recorded.
8.  Event is published to Kafka.
9.  Notification and settlement consumers process asynchronously.
10. Response returns the committed transaction result.

## Failure scenarios

### Timeout before response

Client retries with the same idempotency key. The existing result is
returned; no duplicate financial transaction is created.

### Fraud dependency unavailable

Circuit breaker opens. Policy either rejects safely or routes to a
controlled hold/review path. It never silently approves because of an
outage.

### Kafka unavailable after DB commit

The transaction remains committed. The durable event stays pending and
is retried. The client does not create a second transaction.

## Failover

Unhealthy instances stop receiving traffic. Database replica promotion
follows the runbook. Consumers resume from committed offsets.
Reconciliation verifies financial totals before normal traffic is
restored.
