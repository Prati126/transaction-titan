# Day 9 --- Fault Tolerance

## Circuit breakers

Separate breakers protect fraud, notification, settlement and other
external dependencies.

States: CLOSED → OPEN → HALF_OPEN → CLOSED.

Open after a rolling failure/slow-call threshold. Half-open allows
limited probes.

## Bulkheads

Separate worker pools and connection pools prevent one dependency from
consuming all resources.

## Retry

Retry only transient failures, with capped exponential backoff and
jitter. Financial commands always use idempotency keys.

## Chaos experiments

1.  Kill one API instance at 12K TPS.
2.  Kill the database primary.
3.  Add 500 ms latency to fraud.
4.  Pause one Kafka broker.
5.  Saturate notification consumers.
6.  Simulate Redis node failure.

Each experiment must specify blast radius, hypothesis, success criteria
and rollback.
