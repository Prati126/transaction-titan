# Day 2 --- Technology Evaluation

## Database

  Option               Performance   Operations    Cost          Team fit   Community
  -------------------- ------------- ------------- ------------- ---------- -----------
  PostgreSQL + Citus   High          Medium        Medium        High       Very high
  CockroachDB          High          Medium        Medium-high   Medium     High
  TiDB                 High          Medium-high   Medium        Medium     High

**Decision:** PostgreSQL-compatible sharded relational architecture.

## Message queue

  Option       Throughput   Operations   Cost          Team fit
  ------------ ------------ ------------ ------------- ----------
  Kafka        Very high    Medium       Medium        High
  RabbitMQ     High         Medium       Medium        High
  Amazon SQS   High         Low          Usage-based   Medium

**Decision:** Kafka because partitioning, replay and consumer groups fit
the 12K+ TPS event workload.

## Cache

  Option          Latency    Operations    Cost     Team fit
  --------------- ---------- ------------- -------- ----------
  Redis Cluster   Very low   Medium        Medium   High
  Memcached       Very low   Low           Low      High
  Hazelcast       Low        Medium-high   Medium   Medium

**Decision:** Redis Cluster.

The comparison is a design evaluation, not a claim that the selected
products are universally superior.
