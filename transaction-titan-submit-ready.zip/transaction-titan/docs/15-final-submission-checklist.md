# Day 15 --- Final Submission Checklist

-   Consolidate Day 1--14 deliverables.
-   Follow the assignment's required naming convention.
-   Export readable PDFs where requested.
-   Validate repository history and conventional commits.
-   Rehearse 15-minute ARB + 20-minute Q&A.
-   Keep local copies secure.
-   If the assignment portal requires repository ownership transfer,
    perform it only after final verification.
