# Day 11 --- Load Testing Strategy

  ID       Scenario                 Load   Duration Main pass condition
  -------- ---------------- ------------ ---------- ------------------------------
  LT-001   Baseline            1,200 TPS        30m p99 \<100ms
  LT-002   Target             12,000 TPS        60m stable p99 \<100ms
  LT-003   Burst              18,000 TPS        15m no uncontrolled queue growth
  LT-004   Soak                9,600 TPS         4h no resource leak
  LT-005   Ramp                0→15K TPS        30m graceful scaling
  LT-006   Failover              12K TPS        30m recovery + reconciliation
  LT-007   Mixed workload        12K TPS        60m critical path SLA
  LT-008   Hot partition          5K TPS        10m no partition collapse

Metrics: throughput, p50/p95/p99, errors, DB locks/CPU/lag, Kafka lag,
Redis hit rate, memory and connection utilization.
