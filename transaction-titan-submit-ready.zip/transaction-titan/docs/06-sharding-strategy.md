# Day 6 --- Sharding Strategy

## Candidate keys

-   `account_id`: strongest financial locality; risk is hot accounts.
-   `user_id`: good user locality but users may own multiple accounts.
-   Geography/composite: useful locality but can create uneven
    distribution.

## Decision

Use `account_id` as the primary logical shard key. A routing layer maps
account IDs to physical shard groups.

## Shard calculation

Planning target = 24,000 TPS.

Assuming a conservative planning capacity of 2,000 TPS per shard group:

`ceil(24,000 / 2,000) = 12 shard groups`

This is a planning assumption and must be validated by load tests.

## Cross-shard transfers

Use durable Saga orchestration and compensating ledger actions. Do not
assume every P2P transfer is a single distributed ACID transaction.

## Rebalancing

Introduce a routing epoch, migrate ownership, verify data, switch
routing, monitor, reconcile, then retire the old ownership.

## Failure handling

Replica promotion, health-aware routing, bounded retries and
reconciliation protect financial consistency.
