# Day 14 --- ARB Presentation

1.  **Problem:** 1,200 TPS current → 12,000 TPS target → 18K burst → 24K
    planning.
2.  **Goals:** p99 \<100ms, 99.99% availability, India residency,
    \<\$45K/month.
3.  **Architecture:** Gateway → Orchestrator → financial services →
    DB/Kafka/Redis.
4.  **Correctness:** OCC + immutable ledger + idempotency + durable
    events.
5.  **Scaling:** account sharding + Kafka partitions + stateless
    horizontal scale.
6.  **Resilience:** breakers + bulkheads + retries + DLQ + failover +
    Saga.
7.  **Performance:** 100ms budget + eight load scenarios.
8.  **Cost:** supplied reference model = \$40,850/month.
9.  **FMEA:** 25 failure modes and targeted mitigations.
10. **Trade-offs:** stronger correctness and scale with higher
    operational complexity.
