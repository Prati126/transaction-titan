# Day 7 --- Message Queue Topology

## Topics

-   `transaction.events`
-   `fraud.events`
-   `settlement.events`
-   `notification.events`
-   `audit.events`
-   `dead-letter.events`

Transaction events use `account_id` as the Kafka key to preserve
per-account ordering. Settlement events can use `merchant_id`.

If one partition is conservatively budgeted at 1,500 TPS:

`ceil(12,000 / 1,500) = 8 partitions`

Final partition count must be benchmarked.

Consumer groups scale independently for fraud, settlement, notification
and audit workloads.

The database is authoritative. Durable outbox/CDC-style publication plus
idempotent consumers provides effectively-once business outcomes even if
messages are delivered more than once.

Transient failures use exponential backoff with jitter. Poison messages
go to a DLQ after bounded attempts.
