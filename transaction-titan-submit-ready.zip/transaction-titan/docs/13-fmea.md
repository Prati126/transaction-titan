# Day 13 --- FMEA

RPN = Severity × Occurrence × Detection, using 1--10 scales.

    \# Failure mode                          S   O   D   RPN
  ---- ---------------------------------- ---- --- --- -----
     1 DB primary failure                   10   4   3   120
     2 Double debit                         10   3   2    60
     3 Duplicate retry                       9   6   2   108
     4 Kafka broker failure                  8   4   3    96
     5 Consumer lag                          7   6   4   168
     6 Redis node failure                    6   5   4   120
     7 Fraud timeout                         8   6   4   192
     8 Notification outage                   4   7   2    56
     9 Hot account                           8   6   5   240
    10 Shard imbalance                       8   5   5   200
    11 Connection exhaustion                 8   5   5   200
    12 Memory leak                           7   4   6   168
    13 Bad cache invalidation                9   4   6   216
    14 Outbox publisher failure              8   4   5   160
    15 Poison message                        6   5   3    90
    16 Stale routing map                     8   3   6   144
    17 Replica lag                           8   5   5   200
    18 Rate-limit bypass                     7   4   5   140
    19 Settlement duplication                9   3   3    81
    20 Clock skew                            5   3   7   105
    21 Bad deployment                        8   3   4    96
    22 Certificate expiry                    7   2   2    28
    23 Storage exhaustion                    9   3   4   108
    24 Cross-shard compensation failure     10   3   7   210
    25 Observability outage                  5   4   8   160

High-RPN mitigations include hot-key controls, versioned cache + DB
authority, and durable Saga/reconciliation for cross-shard compensation.
