# Day 8 --- Concurrency Control

## OCC

Each account has a monotonically increasing `version`. A balance update
includes `WHERE account_id = ? AND version = expected_version`. Only one
concurrent writer can advance a given version.

### Correctness argument

If two debits read version V, both attempt to write V+1. Only one update
can match version V. The loser observes zero affected rows and retries
against the new balance. Therefore both cannot consume the same balance
state.

## Locking

Locks are not the primary correctness mechanism. When distributed
coordination is needed, fencing tokens prevent stale lock holders from
writing.

## Isolation

-   Balance mutation: READ COMMITTED + OCC.
-   Ledger insertion: same financial transaction.
-   Reporting: replica/snapshot-safe reads.
-   Settlement aggregation: snapshot/repeatable-read semantics where
    required.

## Saga

Cross-shard transfers use durable state and compensating actions.
