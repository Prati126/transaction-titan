# Day 3 --- High-Level Design

## Components

1.  API Gateway
2.  Authentication/Authorization
3.  Transaction Orchestrator
4.  Account Service
5.  Payment Service
6.  Fraud Detection
7.  Kafka Event Backbone
8.  PostgreSQL Shards + Replicas
9.  Redis Cluster
10. Notification Service
11. Settlement Service
12. Observability
13. India-region disaster recovery capability

## Main flow

Client → Gateway → Auth → Transaction Orchestrator →
Fraud/Account/Payment → Database commit → durable event → Kafka →
asynchronous consumers.

The synchronous path is deliberately short. Notifications and settlement
preparation do not block the financial authorization path.

See `diagrams/system-architecture.puml` and the editable
`system-architecture.drawio`.
