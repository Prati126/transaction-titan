# Day 10 --- API Specification

The complete contract is in `api/openapi.yaml`.

Core endpoints: - `POST /v1/payments` -
`GET /v1/payments/{transactionId}` -
`GET /v1/accounts/{accountId}/transactions` - `POST /v1/settlements` -
`GET /v1/health`

All payment creation requests require `Idempotency-Key`.

Errors use stable machine-readable codes and correlation IDs.
Transaction history uses cursor pagination. Rate limits apply by
endpoint and account tier.
