# Day 5 --- Database Schema

Financial amounts use integer minor units (`BIGINT`). Ledger entries are
append-oriented. Account balance mutations use optimistic concurrency
control. Transactions and ledger entries are time-partitioned.

Tables: - accounts - transactions - ledger_entries - users -
transaction_events - fraud_rules - merchant_settlements -
notification_log

Important indexes: - accounts(user_id) - transactions(account_id,
created_at) - transactions(idempotency_key) UNIQUE -
transactions(status, created_at) - ledger_entries(account_id,
created_at) - transaction_events(status, next_attempt_at) -
merchant_settlements(merchant_id, settlement_date) -
notification_log(transaction_id, channel) UNIQUE
